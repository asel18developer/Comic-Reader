bitjs: Binary Tools for JavaScript
